Welcome to LuaOb1.5
extract all item to same directory
Do not rename all item
Run the install.bat to install