Welcome to LuaOb1.5
Do not rename all item
Run the install.bat to install